﻿namespace P3AddNewFunctionalityDotNetCore.Models.ViewModels
{
    public class LanguageViewModel
    {
        public string Language { get; set; }
    }
}
